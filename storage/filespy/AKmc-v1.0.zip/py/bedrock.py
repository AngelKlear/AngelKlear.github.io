import time
import webbrowser
    
print('AKmc - Bedrock Server | by AngelKlear (CepoRT)')
print(' ')
versionmc = input('Введите версию майнкрафта: ')
url = 'https://www.minecraft.net/bedrockdedicatedserver/bin-win/bedrock-server-' + versionmc + '.zip'

file = open('bedrock.akmc', 'w') 
file.write(versionmc + ' - ' + url)
file.close()

print('Страница скачивание откроется сама через 10 сек...')
print('Ссылка: ' + url)
time.sleep(10)
webbrowser.open(url)