import time
import webbrowser
    
print('AKmc - Java Server | by AngelKlear (CepoRT)')
print(' ')
versionmc = input('Введите версию майнкрафта: ')
url = 'https://serverjar.org/download-version/vanilla/' + versionmc

file = open('java.akmc', 'w') 
file.write(versionmc + ' - ' + url)
file.close()

print('Страница скачивание откроется сама через 10 сек...')
print('Ссылка: ' + url)
time.sleep(10)
webbrowser.open(url)