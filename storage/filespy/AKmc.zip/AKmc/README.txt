Привет, я AngelKlear!

Если прога не работает, то установите Python 3.13

И скачайте модули:

pip install tkinter
pip install webbrowser
pip install time (не нужно, если есть)

или же

pip3 install tkinter
pip3 install webbrowser
pip3 install time (не нужно, если есть)


	КОМАНДА "CepoRT Studio"
